void *mem_init(int size);
void *mem_sbrk(int incr);

