/* $begin main */
/* main.c */
void swap();

int buf[2] = {1, 2};

int main() 
{
    swap();
    return 0;
}
/* $end main */

